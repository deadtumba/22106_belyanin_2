﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _22106_Belyanin_2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int a = 0;
            int b = 0;
            int c = 0;
            int p = 0;
            string predl = Tb1.Text;
            char[] glas = new char[] { 'a', 'e', 'u', 'i', 'o', 'y' };
            char[] alph = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'l', 'k','o','p','q','i','u','m','n','s','w','c','v','z','r','',' '};
            char[] bukv = predl.ToCharArray();
            for (int i = 0; i < bukv.Length; i++)
            {
                if ((bukv[i] == '.') || (bukv[i] == ',') || (bukv[i] == '?') || (bukv[i] == '!') || (bukv[i] == ':') || (bukv[i] == ';') || (bukv[i] == '"') || (bukv[i] == '(') || (bukv[i] == ')') || (bukv[i] == '"'))
                {
                    bukv[i] = '';
                }
                TB1.Text = TB1.Text + bukv[i];
                for(int j = 0; j< alph.Length; j++)
                {
                    if(bukv[i] == alph[j])
                    {
                        
                    }
                    else
                    {
                        a++;
                    }
                }
            }
            if (a == 0)
            {
                for (int i = 0; i < bukv.Length; i++)
                {
                    for (int k = 0; k < glas.Length; k++)
                    {
                        if (bukv[i] == glas[k])
                        {
                            b++;
                        }
                    }
                }
                string[] words = predl.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                for(int i = 0; i< words.Length; i++)
                {
                    char[] simvol = words[i].Split(new char[] {''});
                    int s = simvol.Length;
                    if(s > c)
                    {
                        c = s;
                        p = i;
                    }
                    else
                    {

                    }
                }
                TB1.Text = TB1.Text + "Количество гласных = " + c + " Самое длинное слово " + words[p];
            }
            
        }
    }
}
